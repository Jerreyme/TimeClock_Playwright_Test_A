module.exports = {
    email : 'input[name="email"]',
    password : 'input[name="password"]',
    signIn : 'button[type="submit"]'
}
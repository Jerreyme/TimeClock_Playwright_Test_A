module.exports = {
    timeClockMenu : "//span[@class='flex-1 truncate text-left font-semibold' and text()='Time Clock']",
    timeClockModal : "//div[@class='flex flex-col space-y-6 rounded-lg']",
    timeClockModalHeader : "//span[@class='select-none font-semibold sm:text-lg' and text()='Time Clock']",
    timeClockClientField : "//button[@role='combobox']",
    clockInBtn : "//button[text()='Clock In']",



}
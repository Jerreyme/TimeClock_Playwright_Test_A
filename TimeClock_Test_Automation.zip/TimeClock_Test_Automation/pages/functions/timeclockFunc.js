const timeClockLocators = require('../locators/timeclockLoc');
const ActionDriver = require('../../utils/ActionDriver');

exports.TimeClockPage = class TimeClockPage {
    constructor(page) {
        this.page = page;
        this.actionDriver = new ActionDriver(page);
    }

    async checkTimeClockElementsVisibility() {
        await this.actionDriver.checkElementVisibility(timeClockLocators.timeClockMenu);
    }

    async clickTimeClockMenu() {
        await this.actionDriver.clickButton(timeClockLocators.timeClockMenu);
    }

    async checkTimeClockModalElementsVisibility() {
        await this.actionDriver.checkElementVisibility(timeClockLocators.timeClockModal);
        await this.actionDriver.checkElementVisibility(timeClockLocators.timeClockModalHeader);
        await this.actionDriver.checkElementVisibility(timeClockLocators.clockInBtn);
    }

    async clickTimeClockClientField() {
        await this.actionDriver.clickButton(timeClockLocators.timeClockClientField);
        await sleep(1000);
        await this.actionDriver.clickButton(timeClockLocators.timeClockClientField);
        await sleep(1000);
    }
    async clickTimeClockClockInbtn() {
        await this.actionDriver.clickButton(timeClockLocators.clockInBtn);
        await sleep(2000);
    }
}

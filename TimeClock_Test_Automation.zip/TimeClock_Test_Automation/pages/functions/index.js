module.exports = {
    LoginPage: require('./loginFunc').LoginPage,
    TimeClockPage: require('./timeclockFunc').TimeClockPage,
};

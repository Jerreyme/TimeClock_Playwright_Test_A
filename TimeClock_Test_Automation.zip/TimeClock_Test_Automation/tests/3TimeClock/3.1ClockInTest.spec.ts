import { test } from '@playwright/test';
const { LoginPage, TimeClockPage} = require('../../pages/functions/index.js');


let browser;
let context;
let page;
let loginPage;
let timeClockPage;

test.beforeAll(async ({ browser: b }) => {
    browser = b;
})
test.beforeEach(async () => {
    context = await browser.newContext();
    page = await context.newPage();
    loginPage = new LoginPage(page);
    timeClockPage = new TimeClockPage(page);
    await loginPage.login(process.env.ADMIN, process.env.PASSWORD);
});

test.afterEach(async () => {
    await context.close();
});

test ('Clock In', async () => {
    await timeClockPage.checkTimeClockElementsVisibility();
    await timeClockPage.clickTimeClockMenu();
    await timeClockPage.checkTimeClockModalElementsVisibility();
    await timeClockPage.clickTimeClockClientField();
    await timeClockPage.clickTimeClockClockInbtn();
})
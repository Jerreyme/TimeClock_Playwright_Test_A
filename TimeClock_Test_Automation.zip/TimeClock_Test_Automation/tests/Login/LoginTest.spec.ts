import { test } from '@playwright/test';
const { LoginPage} = require('../../pages/functions/index.js');


let browser;
let context;
let page;
let loginPage;

test.beforeAll(async ({ browser: b }) => {
    browser = b;
})
test.beforeEach(async () => {
    context = await browser.newContext();
    page = await context.newPage();
    loginPage = new LoginPage(page);
    await loginPage.login(process.env.ADMIN, process.env.PASSWORD);
});

test.afterEach(async () => {
    await context.close();
});
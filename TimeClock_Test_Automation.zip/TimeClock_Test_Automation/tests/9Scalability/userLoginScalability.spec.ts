import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/functions/loginFunc';
import dotenv from 'dotenv';

dotenv.config();

test.describe('Scalability Test with Custom Metrics', () => {
    const totalUsers = 10; // Set to 500 in production for full-scale testing
    //const userCredentials = []; //This is for javascript
    const userCredentials: { username: string; password: string }[] = [];
    //const baseUrl = process.env.TEST_ENV; // Your app's base URL - This is for javascript
    const baseUrl: string = process.env.TEST_ENV || 'http://default-url';



    // Generate test credentials dynamically
    for (let i = 1; i <= totalUsers; i++) {
        userCredentials.push({
            username: `test_user_${i}`,
            password: `password${i}`,
        });
    }

    test('Handle concurrent user logins with tracing and network monitoring', async ({ browser }) => {
        const loginPromises = userCredentials.map(async (credentials) => {
            const context = await browser.newContext();

            // Enable tracing
            await context.tracing.start({ screenshots: true, snapshots: true });

            const page = await context.newPage();
            const loginPage = new LoginPage(page);

            // Track network requests
            page.on('request', (request) => {
                console.log(`Request: ${request.method()} ${request.url()}`);
            });
            page.on('response', (response) => {
                console.log(`Response: ${response.status()} ${response.url()}`);
            });

            try {
                const startTime = performance.now();
                await page.goto(baseUrl);
                await loginPage.login(credentials.username, credentials.password);

                // Verify login success
                await expect(page.locator('text=Dashboard')).toBeVisible();
                const endTime = performance.now();
                console.log(
                    `Login time for user ${credentials.username}: ${endTime - startTime} ms`
                );
            } catch (error) {
                console.error(`Login failed for user ${credentials.username}`, error);
            } finally {
                // Stop tracing and save trace
                await context.tracing.stop({ path: `trace-${credentials.username}.zip` });
                await context.close();
            }
        });

        // Wait for all logins to complete
        const startTime = performance.now();
        await Promise.all(loginPromises);
        const endTime = performance.now();

        console.log(`Total time for ${totalUsers} concurrent logins: ${endTime - startTime} ms`);
    });
});
